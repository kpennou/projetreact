import styles from '../styles/Banner.module.css'
import logo from '../assets/logo.png'

const Banner = () => {
  const title = 'La maison jungle'
  return (
    <div className={styles.banner}>
      <img
        src={logo}
        alt="Logo de la jungle"
        className={styles.banner-logo}
      />
      <h1 className={styles.title}>{title}</h1>
    </div>
  )
}
export default Banner